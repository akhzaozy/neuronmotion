/**
 * ============================================================
 * NEURONMOTION — Enhanced Scoring Engine
 * Menggabungkan rule-based threshold + K-NN classification
 * ============================================================
 */

import { CLINICAL_REFERENCE, getClassifier } from '../data/clinicalData.js';

/**
 * Analisis Tremor (enhanced)
 */
export function analyzeTremor({ samples, bodyPart = 'WRIST_RIGHT' }) {
  if (!samples || samples.length < 10)
    return { error: 'Minimal 10 sampel dibutuhkan' };

  const avgX = samples.reduce((s, p) => s + p.x, 0) / samples.length;
  const avgY = samples.reduce((s, p) => s + p.y, 0) / samples.length;
  const displacements = samples.map(p => Math.hypot(p.x - avgX, p.y - avgY));
  const amplitude = Math.sqrt(displacements.reduce((s, d) => s + d * d, 0) / displacements.length);

  // Zero-crossing frequency estimate
  const centered = displacements.map(d => d - amplitude);
  let crossings = 0;
  for (let i = 1; i < centered.length; i++)
    if (centered[i - 1] * centered[i] < 0) crossings++;

  let durationSec = samples.length / 30; // assume 30fps
  if (samples[0]?.timestamp !== undefined)
    durationSec = (samples[samples.length - 1].timestamp - samples[0].timestamp) / 1000 || 1;

  const dominantFrequencyHz = crossings / (2 * Math.max(durationSec, 0.1));
  const ref = CLINICAL_REFERENCE.tremor;

  let category, interpretation, score, updrsEstimate;

  if (amplitude < ref.normalAmplitudeMax) {
    category = 'NORMAL'; score = 0; updrsEstimate = 0;
    interpretation = `Tidak ada tremor signifikan (amplitudo ${(amplitude * 1000).toFixed(1)}mm).`;
  } else if (dominantFrequencyHz >= ref.parkinsonsFreqMin && dominantFrequencyHz <= ref.parkinsonsFreqMax) {
    category = 'PARKINSON_TREMOR'; score = 85; updrsEstimate = 3;
    interpretation = `⚠️ Tremor istirahat ${dominantFrequencyHz.toFixed(1)} Hz di ${bodyPart} — pola khas Parkinson (4-6 Hz). Konsultasi spesialis saraf segera.`;
  } else if (dominantFrequencyHz > ref.essentialTremorMin && dominantFrequencyHz <= ref.essentialTremorMax) {
    category = 'ESSENTIAL_TREMOR'; score = 55; updrsEstimate = 2;
    interpretation = `Tremor frekuensi tinggi ${dominantFrequencyHz.toFixed(1)} Hz — kemungkinan Essential Tremor (bukan Parkinson).`;
  } else if (amplitude > ref.pathologicalAmplitude) {
    category = 'PATHOLOGICAL'; score = 60; updrsEstimate = 2;
    interpretation = `Tremor amplitudo tinggi (${(amplitude * 1000).toFixed(1)}mm), perlu evaluasi lebih lanjut.`;
  } else if (amplitude > ref.borderlineAmplitudeMax) {
    category = 'BORDERLINE'; score = 25; updrsEstimate = 1;
    interpretation = `Getaran ringan terdeteksi. Pantau berkala.`;
  } else {
    category = 'MINIMAL'; score = 10; updrsEstimate = 0;
    interpretation = `Getaran sangat minimal, masih dalam batas normal.`;
  }

  return {
    bodyPart, dominantFrequencyHz: parseFloat(dominantFrequencyHz.toFixed(2)),
    amplitude: parseFloat(amplitude.toFixed(4)), amplitudeMillimeter: parseFloat((amplitude * 1000).toFixed(2)),
    category, interpretation, score, updrsEstimate, sampleCount: samples.length,
  };
}

/**
 * Analisis Finger Tapping (enhanced)
 */
export function analyzeFingerTapping({ taps }) {
  if (!taps || taps.length < 5)
    return { error: 'Minimal 5 data tap dibutuhkan' };

  const peaks = [];
  for (let i = 1; i < taps.length - 1; i++)
    if (taps[i].distance < taps[i - 1].distance && taps[i].distance < taps[i + 1].distance)
      peaks.push(taps[i]);

  const tapCount = peaks.length;
  const durationSec = Math.max((taps[taps.length - 1].timestamp - taps[0].timestamp) / 1000, 0.1);
  const tapRatePerSecond = tapCount / durationSec;

  let decrementPercent = 0;
  if (peaks.length >= 6) {
    const first = peaks.slice(0, Math.ceil(peaks.length / 3));
    const last = peaks.slice(-Math.ceil(peaks.length / 3));
    const avgFirst = first.reduce((s, p) => s + p.distance, 0) / first.length;
    const avgLast = last.reduce((s, p) => s + p.distance, 0) / last.length;
    decrementPercent = avgFirst > 0 ? Math.max(0, ((avgFirst - avgLast) / avgFirst) * 100) : 0;
  }

  const ref = CLINICAL_REFERENCE.fingerTapping;
  let category, interpretation, score, updrsEstimate;

  if (tapRatePerSecond >= ref.normalMin && decrementPercent < ref.decrementNormal) {
    category = 'NORMAL'; score = 0; updrsEstimate = 0;
    interpretation = `Kecepatan tapping normal (${tapRatePerSecond.toFixed(1)} ketuk/det), tidak ada tanda bradikinesia.`;
  } else if (tapRatePerSecond < ref.severeBradykinesia) {
    category = 'SEVERE_BRADYKINESIA'; score = 90; updrsEstimate = 4;
    interpretation = `⚠️ Bradikinesia berat: ${tapRatePerSecond.toFixed(1)} ketuk/det (normal ≥3.5). Evaluasi neurologis segera diperlukan.`;
  } else if (tapRatePerSecond < ref.mildBradykinesia) {
    category = 'MODERATE_BRADYKINESIA'; score = 65; updrsEstimate = 3;
    interpretation = `Bradikinesia sedang: ${tapRatePerSecond.toFixed(1)} ketuk/det. Kemungkinan gangguan motorik signifikan.`;
  } else if (tapRatePerSecond < ref.normalMin) {
    category = 'MILD_BRADYKINESIA'; score = 35; updrsEstimate = 2;
    interpretation = `Bradikinesia ringan: ${tapRatePerSecond.toFixed(1)} ketuk/det. Pantau dan evaluasi.`;
  } else if (decrementPercent > ref.decrementSignif) {
    category = 'SIGNIFICANT_DECREMENT'; score = 60; updrsEstimate = 3;
    interpretation = `Kecepatan awal baik namun turun ${decrementPercent.toFixed(0)}% — tanda akinesia/fatigue motorik khas Parkinson.`;
  } else if (decrementPercent > ref.decrementMild) {
    category = 'MILD_DECREMENT'; score = 35; updrsEstimate = 1;
    interpretation = `Penurunan amplitudo sedang (${decrementPercent.toFixed(0)}%). Perlu pemantauan.`;
  } else {
    category = 'BORDERLINE'; score = 15; updrsEstimate = 1;
    interpretation = `Sedikit di bawah normal, pantau berkala.`;
  }

  return {
    tapCount, tapRatePerSecond: parseFloat(tapRatePerSecond.toFixed(2)),
    decrementPercent: parseFloat(decrementPercent.toFixed(1)),
    durationSec: parseFloat(durationSec.toFixed(2)),
    category, interpretation, score, updrsEstimate,
  };
}

/**
 * Analisis Gait
 */
export function analyzeGait({ steps }) {
  if (!steps || steps.length < 10)
    return { error: 'Minimal 10 frame langkah dibutuhkan' };

  const leftStrides = [], rightStrides = [];
  for (let i = 1; i < steps.length; i++) {
    const dL = Math.abs(steps[i].leftAnkleX - steps[i - 1].leftAnkleX);
    const dR = Math.abs(steps[i].rightAnkleX - steps[i - 1].rightAnkleX);
    if (dL > 0.02) leftStrides.push(dL);
    if (dR > 0.02) rightStrides.push(dR);
  }

  const avg = arr => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
  const avgL = avg(leftStrides), avgR = avg(rightStrides);
  const strideSymmetryIndex = avgL > 0 && avgR > 0
    ? 1 - Math.abs(avgL - avgR) / Math.max(avgL, avgR) : 1;

  const durationSec = Math.max((steps[steps.length - 1].timestamp - steps[0].timestamp) / 1000, 0.1);
  const totalSteps = leftStrides.length + rightStrides.length;
  const cadencePerMin = (totalSteps / durationSec) * 60;

  const ref = CLINICAL_REFERENCE.gait;
  let category, interpretation, score, updrsEstimate;

  if (strideSymmetryIndex >= ref.normalSymmetryMin && cadencePerMin >= ref.normalCadenceMin) {
    category = 'NORMAL'; score = 0; updrsEstimate = 0;
    interpretation = `Pola jalan normal: simetri ${(strideSymmetryIndex * 100).toFixed(0)}%, kadense ${cadencePerMin.toFixed(0)} langkah/menit.`;
  } else if (strideSymmetryIndex < ref.severeAsymmetry) {
    category = 'SEVERE_ASYMMETRY'; score = 88; updrsEstimate = 4;
    interpretation = `⚠️ Asimetri gait berat (${(strideSymmetryIndex * 100).toFixed(0)}%). Risiko tinggi — rujukan segera.`;
  } else if (strideSymmetryIndex < ref.moderateAsymmetry) {
    category = 'MODERATE_ASYMMETRY'; score = 60; updrsEstimate = 3;
    interpretation = `Asimetri gait moderat (${(strideSymmetryIndex * 100).toFixed(0)}%).`;
  } else if (strideSymmetryIndex < ref.mildAsymmetry) {
    category = 'MILD_ASYMMETRY'; score = 35; updrsEstimate = 2;
    interpretation = `Asimetri gait ringan (${(strideSymmetryIndex * 100).toFixed(0)}%).`;
  } else if (cadencePerMin < ref.slowCadence) {
    category = 'SLOW_GAIT'; score = 40; updrsEstimate = 2;
    interpretation = `Gait lambat: ${cadencePerMin.toFixed(0)} langkah/menit (normal ≥100).`;
  } else {
    category = 'BORDERLINE'; score = 15; updrsEstimate = 1;
    interpretation = `Gait sedikit tidak optimal. Pantau.`;
  }

  return {
    cadencePerMin: parseFloat(cadencePerMin.toFixed(1)),
    strideSymmetryIndex: parseFloat(strideSymmetryIndex.toFixed(3)),
    symmetryPercent: parseFloat((strideSymmetryIndex * 100).toFixed(1)),
    category, interpretation, score, updrsEstimate,
  };
}

/**
 * Analisis Arm Swing
 */
export function analyzeArmSwing({ frames }) {
  if (!frames || frames.length < 10)
    return { error: 'Minimal 10 frame dibutuhkan' };

  const leftAngles = frames.map(f => f.leftElbowAngle);
  const rightAngles = frames.map(f => f.rightElbowAngle);
  const amplitude = arr => Math.max(...arr) - Math.min(...arr);
  const leftAmp = amplitude(leftAngles), rightAmp = amplitude(rightAngles);
  const asymmetryPercent = (leftAmp > 0 && rightAmp > 0)
    ? (Math.abs(leftAmp - rightAmp) / Math.max(leftAmp, rightAmp)) * 100 : 0;

  const weakerSide = leftAmp < rightAmp ? 'kiri' : 'kanan';
  const ref = CLINICAL_REFERENCE.armSwing;
  let category, interpretation, score, updrsEstimate;

  if (asymmetryPercent < ref.normalAsymmetryMax && leftAmp >= ref.normalAmplitudeMin && rightAmp >= ref.normalAmplitudeMin) {
    category = 'NORMAL'; score = 0; updrsEstimate = 0;
    interpretation = `Ayunan tangan simetris dan normal (asimetri ${asymmetryPercent.toFixed(0)}%).`;
  } else if (asymmetryPercent > ref.significantAsymmetry) {
    category = 'SIGNIFICANT_ASYMMETRY'; score = 78; updrsEstimate = 3;
    interpretation = `⚠️ Asimetri ayunan tangan signifikan (${asymmetryPercent.toFixed(0)}%) — tangan ${weakerSide} berkurang. Khas pada Parkinson unilateral.`;
  } else if (asymmetryPercent > ref.mildAsymmetry) {
    category = 'MILD_ASYMMETRY'; score = 40; updrsEstimate = 2;
    interpretation = `Asimetri ayunan tangan sedang (${asymmetryPercent.toFixed(0)}%) — tangan ${weakerSide} lebih terbatas.`;
  } else if (leftAmp < ref.reducedAmplitude || rightAmp < ref.reducedAmplitude) {
    category = 'BILATERAL_REDUCTION'; score = 55; updrsEstimate = 2;
    interpretation = `Ayunan tangan bilateral berkurang — indikasi rigiditas.`;
  } else {
    category = 'BORDERLINE'; score = 15; updrsEstimate = 1;
    interpretation = `Ayunan tangan sedikit asimetris, pantau berkala.`;
  }

  return {
    leftAmplitudeDeg: parseFloat(leftAmp.toFixed(1)),
    rightAmplitudeDeg: parseFloat(rightAmp.toFixed(1)),
    asymmetryPercent: parseFloat(asymmetryPercent.toFixed(1)),
    weakerSide, category, interpretation, score, updrsEstimate,
  };
}

/**
 * Analisis Range of Motion
 */
export function analyzeROM({ joint, angles }) {
  if (!angles || angles.length < 3)
    return { error: 'Minimal 3 pengukuran sudut dibutuhkan' };

  const maxAngle = Math.max(...angles), minAngle = Math.min(...angles);
  const rom = maxAngle - minAngle;
  const jKey = (joint || 'KNEE').toUpperCase();
  const ref = CLINICAL_REFERENCE.rom[jKey.toLowerCase()] || CLINICAL_REFERENCE.rom.knee;
  const jointNames = { KNEE: 'lutut', SHOULDER: 'bahu', ELBOW: 'siku', HIP: 'pinggul' };
  const jName = jointNames[jKey] || joint;

  let category, interpretation, score;
  if (rom >= ref.normal) {
    category = 'NORMAL'; score = 0;
    interpretation = `ROM ${jName} normal (${rom.toFixed(0)}°, referensi ≥${ref.normal}°).`;
  } else if (rom >= ref.reduced) {
    category = 'MILDLY_REDUCED'; score = 30;
    interpretation = `ROM ${jName} sedikit terbatas (${rom.toFixed(0)}°). Latihan peregangan dianjurkan.`;
  } else if (rom >= ref.severe) {
    category = 'MODERATELY_REDUCED'; score = 60;
    interpretation = `ROM ${jName} terbatas sedang (${rom.toFixed(0)}°). Evaluasi fisioterapi dianjurkan.`;
  } else {
    category = 'SEVERELY_REDUCED'; score = 85;
    interpretation = `⚠️ ROM ${jName} terbatas berat (${rom.toFixed(0)}°). Rujukan rehabilitasi diperlukan.`;
  }

  return {
    joint: jKey, maxAngleDeg: parseFloat(maxAngle.toFixed(1)),
    minAngleDeg: parseFloat(minAngle.toFixed(1)), romDeg: parseFloat(rom.toFixed(1)),
    referenceNormal: ref.normal, category, interpretation, score,
  };
}

/**
 * Analisis Postural Stability
 */
export function analyzePosturalStability({ frames }) {
  if (!frames || frames.length < 20)
    return { error: 'Minimal 20 frame dibutuhkan' };

  const com = frames.map(f => ({ x: (f.hipX + f.shoulderX) / 2, y: (f.hipY + f.shoulderY) / 2 }));
  let swayLength = 0;
  for (let i = 1; i < com.length; i++)
    swayLength += Math.hypot(com[i].x - com[i - 1].x, com[i].y - com[i - 1].y);

  const xs = com.map(c => c.x), ys = com.map(c => c.y);
  const swayArea = (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys));

  const ref = CLINICAL_REFERENCE.posturalStability;
  let category, interpretation, score, updrsEstimate;

  if (swayLength <= ref.normalSwayLength && swayArea <= ref.normalSwayArea) {
    category = 'STABLE'; score = 0; updrsEstimate = 0;
    interpretation = `Postur stabil (sway area ${(swayArea * 10000).toFixed(2)} cm²).`;
  } else if (swayArea > ref.severeSwayArea || swayLength > ref.severeSwayLength) {
    category = 'SEVERELY_UNSTABLE'; score = 85; updrsEstimate = 4;
    interpretation = `⚠️ Ketidakstabilan postur berat (sway area ${(swayArea * 10000).toFixed(2)} cm²). Risiko jatuh tinggi — rujukan segera.`;
  } else if (swayArea > ref.mildSwayArea || swayLength > ref.mildSwayLength) {
    category = 'MODERATELY_UNSTABLE'; score = 50; updrsEstimate = 2;
    interpretation = `Postur tidak stabil sedang (sway area ${(swayArea * 10000).toFixed(2)} cm²). Latihan keseimbangan dianjurkan.`;
  } else {
    category = 'MILDLY_UNSTABLE'; score = 25; updrsEstimate = 1;
    interpretation = `Postur sedikit tidak stabil. Pantau dan latih keseimbangan.`;
  }

  return {
    swayLengthNorm: parseFloat(swayLength.toFixed(4)),
    swayAreaNorm: parseFloat(swayArea.toFixed(6)),
    swayAreaCm2: parseFloat((swayArea * 10000).toFixed(3)),
    frameCount: frames.length, category, interpretation, score, updrsEstimate,
  };
}

/**
 * Hitung Skor Risiko Komposit dengan ML Classification
 */
export function calculateCompositeRisk(testResults) {
  // Weights berdasarkan sensitivitas diagnostik dari literatur
  const weights = {
    tremor: 0.25,
    fingerTapping: 0.25,
    gait: 0.20,
    armSwing: 0.12,
    posturalStability: 0.12,
    rom: 0.06,
  };

  let weightedScore = 0, totalWeight = 0;
  const breakdown = {};
  const biomarkersForML = {};

  for (const [key, weight] of Object.entries(weights)) {
    if (testResults[key] && typeof testResults[key].score === 'number' && !testResults[key].error) {
      weightedScore += testResults[key].score * weight;
      totalWeight += weight;
      breakdown[key] = {
        score: testResults[key].score,
        category: testResults[key].category,
        updrsEstimate: testResults[key].updrsEstimate,
        interpretation: testResults[key].interpretation,
      };

      // Prepare for ML classifier
      if (key === 'tremor') {
        biomarkersForML.tremor = { dominantFrequencyHz: testResults[key].dominantFrequencyHz, amplitude: testResults[key].amplitude };
      } else if (key === 'fingerTapping') {
        biomarkersForML.fingerTapping = { tapRatePerSecond: testResults[key].tapRatePerSecond, decrementPercent: testResults[key].decrementPercent };
      } else if (key === 'gait') {
        biomarkersForML.gait = { symmetryIndex: testResults[key].strideSymmetryIndex, cadencePerMin: testResults[key].cadencePerMin };
      } else if (key === 'armSwing') {
        biomarkersForML.armSwing = { asymmetryPercent: testResults[key].asymmetryPercent };
      } else if (key === 'posturalStability') {
        biomarkersForML.posturalStability = { swayArea: testResults[key].swayAreaNorm };
      }
    }
  }

  const compositeScore = totalWeight > 0 ? weightedScore / totalWeight : 0;

  let riskCategory, riskColor;
  if (compositeScore >= 65)      { riskCategory = 'HIGH';   riskColor = '🔴'; }
  else if (compositeScore >= 35) { riskCategory = 'MEDIUM'; riskColor = '🟡'; }
  else                           { riskCategory = 'LOW';    riskColor = '🟢'; }

  // K-NN Classification
  let mlResult = null;
  if (Object.keys(biomarkersForML).length >= 2) {
    try {
      const classifier = getClassifier();
      mlResult = classifier.classify(biomarkersForML);
    } catch (e) {
      mlResult = { error: 'Klasifikasi ML tidak tersedia' };
    }
  }

  // Estimasi UPDRS total
  const updrsValues = Object.values(breakdown)
    .map(b => b.updrsEstimate)
    .filter(v => v !== undefined);
  const updrsTotal = updrsValues.reduce((a, b) => a + b, 0);

  // Rekomendasi
  const recommendations = generateRecommendations(riskCategory, breakdown, mlResult);

  return {
    compositeScore: parseFloat(compositeScore.toFixed(1)),
    riskCategory,
    riskLabel: `${riskColor} Risiko ${riskCategory === 'HIGH' ? 'Tinggi' : riskCategory === 'MEDIUM' ? 'Sedang' : 'Rendah'}`,
    mlClassification: mlResult,
    updrsEstimate: { totalMotorScore: updrsTotal, maxPossible: updrsValues.length * 4 },
    breakdown,
    recommendations,
  };
}

function generateRecommendations(risk, breakdown, ml) {
  const recs = [];

  if (risk === 'HIGH') {
    recs.push('Segera lakukan konsultasi dengan dokter spesialis saraf (neurolog).');
    recs.push('Hindari aktivitas yang memerlukan keseimbangan tinggi tanpa pengawasan.');
  } else if (risk === 'MEDIUM') {
    recs.push('Jadwalkan pemeriksaan lanjutan dalam 1-2 minggu ke depan.');
    recs.push('Mulai program latihan fisik terpandu (fisioterapi preventif).');
  }

  if (breakdown.posturalStability?.score > 50)
    recs.push('Latihan keseimbangan: Tai Chi atau fisioterapi berbasis keseimbangan sangat dianjurkan.');
  if (breakdown.gait?.score > 40)
    recs.push('Evaluasi gait oleh fisioterapis dianjurkan untuk mencegah risiko jatuh.');
  if (breakdown.tremor?.category?.includes('PARKINSON'))
    recs.push('Tes pencitraan otak (MRI/DaTscan) perlu dipertimbangkan untuk konfirmasi diagnosis.');
  if (breakdown.fingerTapping?.score > 60)
    recs.push('Latihan motorik halus tangan setiap hari untuk memperlambat progresi bradikinesia.');

  if (ml?.predictedCondition && ml.confidence > 60) {
    recs.push(`Model AI mendeteksi pola yang mirip dengan: ${ml.predictedLabel} (keyakinan ${ml.confidence}%).`);
  }

  if (recs.length === 0)
    recs.push('Tidak ada tindak lanjut mendesak. Tetap jaga kesehatan dan lakukan skrining berkala tiap 6 bulan.');

  return recs;
}
