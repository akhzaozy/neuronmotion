/**
 * Rule-based scoring for Neurological Disorder Screening
 * Extracts key metrics from biomarkers and assigns a risk score.
 */

export function calculateRiskScore(biomarkers) {
  let score = 0;
  let recommendations = [];

  // 1. Tremor check
  // Assumption: tremor is an object { dominantFrequencyHz, amplitude }
  if (biomarkers.tremor) {
    if (biomarkers.tremor.dominantFrequencyHz >= 4 && biomarkers.tremor.dominantFrequencyHz <= 6) {
      score += 40; // High correlation with Parkinson's resting tremor
      recommendations.push("Terdeteksi pola tremor istirahat. Disarankan konsultasi dengan spesialis saraf.");
    } else if (biomarkers.tremor.dominantFrequencyHz > 6) {
      score += 20; // Essential tremor or other action tremor
      recommendations.push("Terdeteksi tremor frekuensi tinggi. Disarankan evaluasi lebih lanjut.");
    }
  }

  // 2. Finger Tapping check
  // Assumption: fingerTapping is an object { tapRatePerSecond, decrementPercentage }
  if (biomarkers.fingerTapping) {
    if (biomarkers.fingerTapping.tapRatePerSecond < 2.5) {
      score += 30; // Bradykinesia
      recommendations.push("Kecepatan tapping jari lambat. Indikasi kemungkinan bradikinesia.");
    }
    if (biomarkers.fingerTapping.decrementPercentage > 20) {
      score += 20;
      recommendations.push("Terjadi penurunan amplitudo/kecepatan saat melakukan tapping berulang (fatigue).");
    }
  }

  // 3. Gait & Postural Stability
  if (biomarkers.gait) {
    if (biomarkers.gait.symmetryIndex < 0.8) {
      score += 25;
      recommendations.push("Terdeteksi asimetri pada pola jalan (gait).");
    }
  }

  if (biomarkers.posturalStability) {
    if (biomarkers.posturalStability.swayArea > 10.0) { // arbitrary threshold
      score += 20;
      recommendations.push("Ketidakstabilan postur terdeteksi (sway area tinggi). Risiko jatuh meningkat.");
    }
  }

  // Cap score at 100
  score = Math.min(score, 100);

  // Categorize
  let riskCategory = "LOW";
  if (score >= 60) riskCategory = "HIGH";
  else if (score >= 30) riskCategory = "MEDIUM";

  if (recommendations.length === 0) {
    recommendations.push("Tidak ada indikasi gangguan gerak yang signifikan. Tetap jaga kesehatan.");
  }

  return {
    riskScore: score,
    riskCategory,
    recommendations: recommendations.join(" ")
  };
}
