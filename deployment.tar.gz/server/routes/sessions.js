import express from 'express';
import { PrismaClient } from '@prisma/client';
import { calculateRiskScore } from '../services/scoring.js';

const router = express.Router();
const prisma = new PrismaClient();

// Submit new session/biomarkers (Mocking auth middleware for simplicity, assuming userId is sent in body or headers)
router.post('/', async (req, res) => {
  try {
    const { patientId, biomarkers } = req.body;
    
    if (!patientId || !biomarkers) {
      return res.status(400).json({ error: 'Missing patientId or biomarkers data' });
    }

    // Calculate risk
    const { riskScore, riskCategory, recommendations } = calculateRiskScore(biomarkers);

    // Save to DB
    const session = await prisma.session.create({
      data: {
        patientId: parseInt(patientId),
        rawBiomarkers: JSON.stringify(biomarkers),
        riskScore,
        riskCategory,
        recommendations
      }
    });

    res.status(201).json({
      message: 'Session recorded',
      session
    });
  } catch (error) {
    console.error('Session Submission Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get session history for a patient
router.get('/:patientId', async (req, res) => {
  try {
    const { patientId } = req.params;
    
    const sessions = await prisma.session.findMany({
      where: { patientId: parseInt(patientId) },
      orderBy: { createdAt: 'desc' }
    });

    res.json(sessions);
  } catch (error) {
    console.error('Fetch Sessions Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add doctor note to session
router.put('/:sessionId/note', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { note } = req.body;

    const session = await prisma.session.update({
      where: { id: parseInt(sessionId) },
      data: { doctorNote: note }
    });

    res.json(session);
  } catch (error) {
    console.error('Update Note Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
