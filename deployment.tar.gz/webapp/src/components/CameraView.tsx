'use client';
import styles from './Camera.module.css';
import { LiveMetrics, TestType } from '@/hooks/useBiomarkerCapture';

interface Props {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  cameraReady: boolean;
  poseReady: boolean;
  isCapturing: boolean;
  activeTest: TestType;
  liveMetrics: LiveMetrics;
  countdown: number;
  error: string | null;
  onStart: () => void;
}

const TEST_LABELS: Record<string, string> = {
  tremor: '🤚 Tremor — Tahan tangan rileks di depan kamera',
  fingerTapping: '☝️ Finger Tapping — Ketuk ibu jari ke telunjuk berulang',
  gait: '🚶 Gait — Berjalan di depan kamera',
  armSwing: '💪 Arm Swing — Berjalan dan biarkan tangan berayun natural',
  posture: '🧍 Postur — Berdiri tegak dan diam di depan kamera',
  rom: '🦵 ROM Lutut — Tekuk dan luruskan lutut secara penuh',
};

export default function CameraView({
  videoRef, canvasRef, cameraReady, poseReady,
  isCapturing, activeTest, liveMetrics, countdown, error, onStart,
}: Props) {
  return (
    <div className={styles.wrapper}>
      {/* Video + Canvas overlay */}
      <div className={styles.videoContainer}>
        <video ref={videoRef} className={styles.video} playsInline muted />
        <canvas ref={canvasRef} className={styles.canvas} />

        {/* Not started overlay */}
        {!cameraReady && !error && (
          <div className={styles.overlay}>
            <div className={styles.startBox}>
              <div className={styles.cameraIcon}>📷</div>
              <h3>Aktifkan Kamera</h3>
              <p>Kamera diperlukan untuk deteksi biomarker real-time</p>
              <button className="btn btn-primary" onClick={onStart}>
                Izinkan Akses Kamera
              </button>
            </div>
          </div>
        )}

        {/* Error overlay */}
        {error && (
          <div className={styles.overlay}>
            <div className={styles.errorBox}>
              <div className={styles.cameraIcon}>⚠️</div>
              <h3>Kamera Tidak Tersedia</h3>
              <p>{error}</p>
              <button className="btn btn-primary" onClick={onStart}>Coba Lagi</button>
            </div>
          </div>
        )}

        {/* Loading MediaPipe */}
        {cameraReady && !poseReady && (
          <div className={styles.loadingBadge}>
            <div className={styles.spinner} />
            Memuat model AI...
          </div>
        )}

        {/* Recording indicator */}
        {isCapturing && (
          <div className={styles.recBadge}>
            <span className={styles.recDot} />
            REC — {countdown}s
          </div>
        )}

        {/* Test instruction */}
        {activeTest && !isCapturing && poseReady && (
          <div className={styles.instructionBadge}>
            {TEST_LABELS[activeTest]}
          </div>
        )}

        {/* Scan lines effect when capturing */}
        {isCapturing && <div className={styles.scanline} />}
      </div>

      {/* Live Metrics bar */}
      {cameraReady && (
        <div className={styles.metricsBar}>
          <MetricChip label="Pose" value={poseReady ? '✅ Aktif' : '⏳ Loading'} color={poseReady ? 'green' : 'yellow'} />
          {liveMetrics.tremorAmp !== undefined && (
            <MetricChip label="Tremor Amp" value={`${liveMetrics.tremorAmp} mm`} color="blue" />
          )}
          {liveMetrics.tapRate !== undefined && (
            <MetricChip label="Tap Rate" value={`${liveMetrics.tapRate} /s`} color="purple" />
          )}
          {liveMetrics.tapCount !== undefined && (
            <MetricChip label="Tap Count" value={String(liveMetrics.tapCount)} color="blue" />
          )}
          {liveMetrics.gaitSymmetry !== undefined && (
            <MetricChip
              label="Simetri Gait"
              value={`${(liveMetrics.gaitSymmetry * 100).toFixed(0)}%`}
              color={liveMetrics.gaitSymmetry >= 0.9 ? 'green' : liveMetrics.gaitSymmetry >= 0.8 ? 'yellow' : 'red'}
            />
          )}
          {liveMetrics.armAsymmetry !== undefined && (
            <MetricChip
              label="Asimetri Lengan"
              value={`${liveMetrics.armAsymmetry}%`}
              color={liveMetrics.armAsymmetry < 15 ? 'green' : liveMetrics.armAsymmetry < 30 ? 'yellow' : 'red'}
            />
          )}
          {liveMetrics.swayArea !== undefined && (
            <MetricChip
              label="Sway Area"
              value={`${liveMetrics.swayArea} cm²`}
              color={liveMetrics.swayArea < 30 ? 'green' : liveMetrics.swayArea < 80 ? 'yellow' : 'red'}
            />
          )}
          {liveMetrics.romKnee !== undefined && (
            <MetricChip label="ROM Lutut" value={`${liveMetrics.romKnee}°`} color="blue" />
          )}
        </div>
      )}
    </div>
  );
}

function MetricChip({ label, value, color }: { label: string; value: string; color: string }) {
  const colorMap: Record<string, string> = {
    green: 'var(--green)', blue: 'var(--brand-light)',
    yellow: 'var(--yellow)', red: 'var(--red)', purple: 'var(--purple)',
  };
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
      padding: '6px 12px', background: 'rgba(14,21,40,0.8)',
      border: '1px solid var(--border)', borderRadius: 8, minWidth: 80,
    }}>
      <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>
      <span style={{ fontSize: '0.88rem', fontWeight: 700, color: colorMap[color] || '#fff', fontFamily: 'JetBrains Mono, monospace' }}>{value}</span>
    </div>
  );
}
