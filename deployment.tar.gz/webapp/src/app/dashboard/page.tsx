'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/lib/auth';
import { api, Session } from '@/lib/api';
import styles from './dashboard.module.css';

export default function DashboardPage() {
  const router = useRouter();
  const { user, token, logout, isLoading } = useAuth();
  
  const [summary, setSummary] = useState<any>(null);
  const [history, setHistory] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isLoading) return;
    if (!user || user.role !== 'PATIENT') {
      router.push('/login');
      return;
    }

    async function loadData() {
      try {
        const [sumRes, histRes] = await Promise.all([
          api.getPatientSummary(user!.id),
          api.getHistory(user!.id, token!)
        ]);
        setSummary(sumRes);
        setHistory(histRes.sessions || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [user, token, isLoading, router]);

  if (isLoading || loading) return <div style={{ padding: 40, textAlign: 'center' }}>Memuat Dashboard...</div>;

  const latestRisk = summary?.riskDistribution ? Object.keys(summary.riskDistribution).pop() : 'LOW';
  
  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <div>
            <h1>Dashboard Pasien</h1>
            <p>Pantau perkembangan kesehatan motorik Anda secara berkala.</p>
          </div>
          <div className={styles.userCard}>
            <div className={styles.avatar}>{user?.name.charAt(0)}</div>
            <div>
              <div className={styles.userName}>{user?.name}</div>
              <div className={styles.userRole}>Pasien Terdaftar</div>
            </div>
            <button className="btn btn-outline btn-sm" onClick={() => { logout(); router.push('/login'); }} style={{ marginLeft: 16 }}>
              Keluar
            </button>
          </div>
        </div>

        <div className={styles.grid}>
          {/* Main Score Card */}
          <div className={styles.card}>
            <h3 className={styles.cardTitle}>Skor Risiko Terkini</h3>
            {summary?.latestScore !== undefined ? (
              <>
                <div 
                  className={styles.scoreValue}
                  style={{ color: latestRisk === 'HIGH' ? 'var(--red)' : latestRisk === 'MEDIUM' ? 'var(--yellow)' : 'var(--green)' }}
                >
                  {Math.round(summary.latestScore)}
                </div>
                <div className={`${styles.badge} ${
                  latestRisk === 'HIGH' ? 'risk-bg-high risk-high' : 
                  latestRisk === 'MEDIUM' ? 'risk-bg-medium risk-medium' : 'risk-bg-low risk-low'
                }`}>
                  Risiko {latestRisk}
                </div>
                <div className={styles.trendBox}>
                  <span>📈</span>
                  Tren: {summary.trendDirection === 'WORSENING' ? 'Meningkat' : summary.trendDirection === 'IMPROVING' ? 'Membaik' : 'Stabil'} 
                  ({summary.trendDelta > 0 ? '+' : ''}{summary.trendDelta})
                </div>
              </>
            ) : (
              <p>Belum ada data. Lakukan skrining pertama Anda.</p>
            )}
          </div>

          {/* Quick Start Card */}
          <div className={styles.ctaBox}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Mulai Tes Skrining</h3>
            <p style={{ fontSize: '0.9rem', opacity: 0.9 }}>Lakukan skrining berkala menggunakan kamera perangkat Anda.</p>
            <Link href="/screening" className="btn" style={{ background: '#fff', color: 'var(--brand)', width: '100%' }}>
              Mulai Skrining Sekarang →
            </Link>
          </div>
        </div>

        {/* History */}
        <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: 24 }}>Riwayat Skrining</h2>
        <div className={styles.historyList}>
          {history.length > 0 ? history.map((session, i) => (
            <div key={session.id} className={styles.historyItem}>
              <div>
                <div className={styles.historyDate}>
                  {new Date(session.timestamp).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </div>
                <div className={styles.historyDesc}>
                  {session.mlPrediction?.predictedLabel ? `🤖 Prediksi AI: ${session.mlPrediction.predictedLabel}` : 'Skrining Standar'}
                </div>
              </div>
              <div 
                className={styles.historyScore}
                style={{ color: session.riskCategory === 'HIGH' ? 'var(--red)' : session.riskCategory === 'MEDIUM' ? 'var(--yellow)' : 'var(--green)' }}
              >
                {Math.round(session.compositeScore)}
              </div>
            </div>
          )) : (
            <div style={{ textAlign: 'center', padding: 40, background: 'var(--bg-card)', borderRadius: 12, border: '1px solid var(--border)' }}>
              Belum ada riwayat pemeriksaan.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
