'use client';
import Link from 'next/link';
import styles from './landing.module.css';

const FEATURES = [
  { icon: '🤚', title: 'Deteksi Tremor', desc: 'Analisis frekuensi & amplitudo tremor istirahat. Mendeteksi pola khas Parkinson (4-6 Hz).' },
  { icon: '☝️', title: 'Finger Tapping', desc: 'Ukur kecepatan ketukan dan pola dekrement — indikator utama bradikinesia.' },
  { icon: '🚶', title: 'Analisis Gait', desc: 'Deteksi asimetri langkah dan kadense berjalan secara real-time via kamera.' },
  { icon: '💪', title: 'Arm Swing', desc: 'Ukur asimetri ayunan tangan kiri vs kanan — gejala awal Parkinson unilateral.' },
  { icon: '🧍', title: 'Stabilitas Postur', desc: 'Hitung sway area dan panjang jalur untuk menilai risiko jatuh.' },
  { icon: '📐', title: 'Range of Motion', desc: 'Evaluasi ROM sendi lutut, bahu, dan siku menggunakan pose estimation.' },
];

const CONDITIONS = [
  { label: 'Parkinson', color: '#ef4444', icon: '🧠' },
  { label: 'Essential Tremor', color: '#f59e0b', icon: '🤲' },
  { label: 'Pasca Stroke', color: '#8b5cf6', icon: '💊' },
  { label: 'Ataksia Serebelar', color: '#3b82f6', icon: '🏥' },
];

export default function LandingPage() {
  return (
    <div className={styles.page}>
      {/* Navbar */}
      <nav className={styles.nav}>
        <div className={styles.navBrand}>
          <span className={styles.navLogo}>🧠</span>
          <span className={styles.navName}>NeuronMotion</span>
          <span className="badge badge-brand">Beta</span>
        </div>
        <div className={styles.navLinks}>
          <Link href="/login" className="btn btn-outline btn-sm">Masuk</Link>
          <Link href="/register" className="btn btn-primary btn-sm">Daftar Gratis</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.heroBg} />
        <div className={styles.heroContent}>
          <div className="badge badge-brand" style={{ marginBottom: 20 }}>
            ✨ Computer Vision + MediaPipe Real-time
          </div>
          <h1 className={styles.heroTitle}>
            Deteksi Dini<br />
            <span className={styles.gradientText}>Gangguan Saraf</span><br />
            Dari Kamera Anda
          </h1>
          <p className={styles.heroDesc}>
            NeuronMotion menggunakan AI dan kamera perangkat Anda untuk menganalisis
            tremor, pola jalan, dan biomarker motorik — membantu deteksi awal
            Parkinson dan gangguan neurologis lainnya.
          </p>
          <div className={styles.heroCTA}>
            <Link href="/register" className="btn btn-primary btn-lg">
              Mulai Skrining Gratis →
            </Link>
            <Link href="/login" className="btn btn-outline btn-lg">
              Sudah Punya Akun
            </Link>
          </div>
          <div className={styles.heroStats}>
            {[['300+', 'Data Training Klinis'], ['6', 'Jenis Tes Biomarker'], ['K-NN', 'ML Classifier'], ['Real-time', 'Via Kamera']].map(([val, label]) => (
              <div key={label} className={styles.statItem}>
                <span className={styles.statVal}>{val}</span>
                <span className={styles.statLabel}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className={styles.section}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <h2>6 Biomarker yang Dianalisis</h2>
            <p>Setiap tes menggunakan MediaPipe pose estimation untuk mengekstrak data dari gerakan tubuh Anda</p>
          </div>
          <div className={styles.featureGrid}>
            {FEATURES.map(f => (
              <div key={f.title} className={styles.featureCard}>
                <div className={styles.featureIcon}>{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Conditions */}
      <section className={styles.section} style={{ paddingTop: 0 }}>
        <div className={styles.container}>
          <div className={styles.conditionBox}>
            <div className={styles.sectionHeader}>
              <h2>Kondisi yang Dapat Dideteksi</h2>
              <p>Model K-NN dilatih dengan 300+ profil pasien sintetis berbasis data klinis</p>
            </div>
            <div className={styles.conditionGrid}>
              {CONDITIONS.map(c => (
                <div key={c.label} className={styles.conditionChip} style={{ borderColor: c.color + '44', background: c.color + '15' }}>
                  <span>{c.icon}</span>
                  <span style={{ color: c.color, fontWeight: 600 }}>{c.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className={styles.ctaSection}>
        <div className={styles.ctaBox}>
          <h2>Mulai Skrining Sekarang</h2>
          <p>Gratis, privat, dan tidak memerlukan perangkat tambahan — hanya kamera.</p>
          <Link href="/register" className="btn btn-primary btn-lg">
            Buat Akun & Mulai Skrining →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <p>⚠️ NeuronMotion adalah alat skrining awal. Bukan pengganti diagnosis dokter.</p>
        <p style={{ marginTop: 4, fontSize: '0.75rem', color: 'var(--text-muted)' }}>
          Berdasarkan: MDS-UPDRS • Shimoyama 1990 • Zijlstra & Hof 2003 • mPower Study
        </p>
      </footer>
    </div>
  );
}
