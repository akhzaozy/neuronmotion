'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import styles from '../login/auth.module.css';

export default function RegisterPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('PATIENT');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await api.register(email, password, name, role);
      // Auto-login after register
      const data = await api.login(email, password);
      // We don't have direct access to auth context here without wrapping or importing,
      // but usually register redirects to login or handles it.
      // Let's just redirect to login for simplicity.
      router.push('/login');
    } catch (err: any) {
      setError(err.message || 'Gagal mendaftar. Email mungkin sudah terpakai.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.bgElements}>
        <div className={styles.circle1} />
        <div className={styles.circle2} />
      </div>

      <div className={`${styles.authCard} glass`}>
        <div className={styles.header}>
          <div className={styles.logo}>🧠</div>
          <h1 className={styles.title}>Buat Akun</h1>
          <p className={styles.subtitle}>Mulai deteksi dini hari ini</p>
        </div>

        {error && <div className={styles.errorBox}>{error}</div>}

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label className={styles.label}>Nama Lengkap</label>
            <input
              type="text"
              className="input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Contoh: Budi Santoso"
              required
            />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label}>Email</label>
            <input
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Contoh: budi@email.com"
              required
            />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label}>Password</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimal 6 karakter"
              required
            />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label}>Saya mendaftar sebagai:</label>
            <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="PATIENT">Pasien</option>
              <option value="DOCTOR">Dokter / Nakes</option>
            </select>
          </div>

          <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ marginTop: 10 }}>
            {loading ? 'Memproses...' : 'Daftar Sekarang'}
          </button>
        </form>

        <div className={styles.footer}>
          Sudah punya akun? <Link href="/login" className={styles.link}>Masuk di sini</Link>
        </div>
      </div>
    </div>
  );
}
