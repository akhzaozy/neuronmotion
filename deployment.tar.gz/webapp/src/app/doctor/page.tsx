'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth';
import { api, PatientDetail, Session } from '@/lib/api';
import styles from './doctor.module.css';

export default function DoctorPortal() {
  const router = useRouter();
  const { user, token, logout, isLoading } = useAuth();
  
  const [dashboard, setDashboard] = useState<any>(null);
  const [patients, setPatients] = useState<any[]>([]);
  const [activePatient, setActivePatient] = useState<PatientDetail | null>(null);
  const [noteText, setNoteText] = useState('');
  const [isSavingNote, setIsSavingNote] = useState(false);

  useEffect(() => {
    if (isLoading) return;
    if (!user || user.role !== 'DOCTOR') {
      router.push('/login');
      return;
    }

    async function loadData() {
      try {
        const [dashRes, patsRes] = await Promise.all([
          api.getDoctorDashboard(user!.id, token!),
          api.getDoctorPatients(user!.id, token!)
        ]);
        setDashboard(dashRes);
        setPatients(patsRes.patients || []);
      } catch (e) {
        console.error(e);
      }
    }

    loadData();
  }, [user, token, isLoading, router]);

  const loadPatientDetail = async (patientId: number) => {
    try {
      const detail = await api.getPatient(patientId, token!);
      setActivePatient(detail);
      setNoteText(detail.sessions[0]?.doctorNote || '');
    } catch (e) {
      alert('Gagal memuat detail pasien');
    }
  };

  const saveNote = async () => {
    if (!activePatient || !activePatient.sessions[0]) return;
    setIsSavingNote(true);
    try {
      await api.saveNote(activePatient.sessions[0].id, { note: noteText, doctorId: user!.id }, token!);
      alert('Catatan berhasil disimpan');
    } catch (e: any) {
      alert('Gagal menyimpan: ' + e.message);
    } finally {
      setIsSavingNote(false);
    }
  };

  if (isLoading || !dashboard) return <div style={{ padding: 40, textAlign: 'center' }}>Memuat Portal Nakes...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <div>
            <h1>Portal Tenaga Kesehatan</h1>
            <p>Selamat datang, {user?.name} — {user?.specialization || 'Dokter Spesialis'}</p>
          </div>
          <button className="btn btn-outline" onClick={() => { logout(); router.push('/login'); }}>
            Keluar
          </button>
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <div className={styles.statTitle}>Total Pasien Aktif</div>
            <div className={styles.statValue} style={{ color: 'var(--brand-light)' }}>{dashboard.totalPatients}</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statTitle}>Pasien Risiko Tinggi (Rujukan)</div>
            <div className={styles.statValue} style={{ color: 'var(--red)' }}>{dashboard.riskBreakdown?.HIGH || 0}</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statTitle}>Pasien Risiko Sedang (Pantau)</div>
            <div className={styles.statValue} style={{ color: 'var(--yellow)' }}>{dashboard.riskBreakdown?.MEDIUM || 0}</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statTitle}>Deteksi Parkinson Awal</div>
            <div className={styles.statValue} style={{ color: 'var(--purple)' }}>{dashboard.conditionBreakdown?.PARKINSON_EARLY || 0}</div>
          </div>
        </div>

        <div className={styles.contentGrid}>
          {/* Patient List */}
          <div className={styles.patientList}>
            <div className={styles.listHeader}>
              <span>Daftar Pasien ({patients.length})</span>
            </div>
            <div className={styles.listBody}>
              {patients.map(p => (
                <div 
                  key={p.id} 
                  className={`${styles.patientItem} ${activePatient?.id === p.id ? styles.active : ''}`}
                  onClick={() => loadPatientDetail(p.id)}
                >
                  <div>
                    <div className={styles.patientName}>{p.name}</div>
                    <div className={styles.patientInfo}>Usia: {p.age || '?'} th • Skor: {p.lastSession ? Math.round(p.lastSession.compositeScore) : '-'}</div>
                  </div>
                  {p.lastSession && (
                    <div className={`${styles.riskIndicator} ${styles[p.lastSession.riskCategory]}`} title={`Risiko ${p.lastSession.riskCategory}`} />
                  )}
                </div>
              ))}
              {patients.length === 0 && <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-secondary)' }}>Belum ada pasien tertaut.</div>}
            </div>
          </div>

          {/* Detail View */}
          <div className={styles.detailView}>
            {activePatient ? (
              <>
                <div className={styles.detailHeader}>
                  <div>
                    <h2 className={styles.detailTitle}>{activePatient.name}</h2>
                    <div style={{ color: 'var(--text-secondary)' }}>{activePatient.email} • Usia {activePatient.age || '?'} tahun • {activePatient.gender === 'M' ? 'Laki-laki' : 'Perempuan'}</div>
                  </div>
                  {activePatient.sessions[0] && (
                    <div className={`badge ${
                      activePatient.sessions[0].riskCategory === 'HIGH' ? 'badge-red' : 
                      activePatient.sessions[0].riskCategory === 'MEDIUM' ? 'badge-yellow' : 'badge-green'
                    }`} style={{ fontSize: '1rem', padding: '8px 16px' }}>
                      Risiko {activePatient.sessions[0].riskCategory} (Skor: {Math.round(activePatient.sessions[0].compositeScore)})
                    </div>
                  )}
                </div>

                {activePatient.sessions[0] ? (
                  <div>
                    <h3 style={{ marginBottom: 16 }}>Sesi Skrining Terakhir: {new Date(activePatient.sessions[0].timestamp).toLocaleDateString('id-ID')}</h3>
                    
                    {activePatient.sessions[0].mlPrediction?.predictedLabel && (
                      <div style={{ background: 'var(--bg-secondary)', padding: 16, borderRadius: 8, marginBottom: 24, borderLeft: '4px solid var(--purple)' }}>
                        <h4 style={{ color: 'var(--purple)', marginBottom: 4 }}>🤖 AI ML Prediction</h4>
                        <p style={{ fontWeight: 600 }}>{activePatient.sessions[0].mlPrediction.predictedLabel}</p>
                        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: 4 }}>
                          Confidence: {activePatient.sessions[0].mlPrediction.confidence || '?'}%
                        </p>
                      </div>
                    )}

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 32 }}>
                      <div style={{ background: 'var(--bg-secondary)', padding: 16, borderRadius: 8 }}>
                        <h4 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 8 }}>Tremor Amplitude</h4>
                        <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>
                          {(activePatient.sessions[0].tremorResult as any)?.amplitudeMillimeter || '-'} mm
                        </div>
                      </div>
                      <div style={{ background: 'var(--bg-secondary)', padding: 16, borderRadius: 8 }}>
                        <h4 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 8 }}>Finger Tapping Rate</h4>
                        <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>
                          {(activePatient.sessions[0].fingerTappingResult as any)?.tapRatePerSecond || '-'} tap/s
                        </div>
                      </div>
                      <div style={{ background: 'var(--bg-secondary)', padding: 16, borderRadius: 8 }}>
                        <h4 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 8 }}>Gait Symmetry</h4>
                        <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>
                          {(activePatient.sessions[0].gaitResult as any)?.symmetryPercent || '-'}%
                        </div>
                      </div>
                      <div style={{ background: 'var(--bg-secondary)', padding: 16, borderRadius: 8 }}>
                        <h4 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 8 }}>Postural Sway Area</h4>
                        <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>
                          {(activePatient.sessions[0].posturalResult as any)?.swayAreaCm2 || '-'} cm²
                        </div>
                      </div>
                    </div>

                    <div className={styles.noteSection}>
                      <h3 style={{ marginBottom: 16 }}>Catatan Klinis Dokter</h3>
                      <textarea 
                        className="input" 
                        value={noteText}
                        onChange={e => setNoteText(e.target.value)}
                        placeholder="Tulis hasil evaluasi dan rekomendasi medis untuk pasien..."
                      />
                      <button className="btn btn-primary" onClick={saveNote} disabled={isSavingNote}>
                        {isSavingNote ? 'Menyimpan...' : 'Simpan Catatan & Rekomendasi'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className={styles.emptyState}>
                    <p>Pasien ini belum melakukan skrining sama sekali.</p>
                  </div>
                )}
              </>
            ) : (
              <div className={styles.emptyState}>
                <div className={styles.emptyStateIcon}>📋</div>
                <h3>Pilih Pasien</h3>
                <p>Klik nama pasien di menu sebelah kiri untuk melihat detail klinis lengkap dan analisis biomarker.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
